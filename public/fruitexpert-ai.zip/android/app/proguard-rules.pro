# ProGuard rules for FruitExpert AI

# Keep serialization properties
-keepclassmembers class * {
    @kotlinx.serialization.Serializable *;
}

# Keep our retrofit API service interfaces intact
-keep class com.fruitexpert.ai.data.** { *; }

# Keep OkHttp & Retrofit annotations
-keepattributes Signature, InnerClasses, EnclosingMethod, Annotation
-dontwarn okhttp3.**
-dontwarn retrofit2.**
-dontwarn kotlinx.serialization.**
