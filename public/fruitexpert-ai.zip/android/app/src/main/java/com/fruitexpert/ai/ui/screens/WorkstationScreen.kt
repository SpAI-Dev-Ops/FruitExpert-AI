package com.fruitexpert.ai.ui.screens

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import com.fruitexpert.ai.data.ApiService
import com.fruitexpert.ai.data.FruitData
import com.fruitexpert.ai.data.NutritionalValue
import com.fruitexpert.ai.data.Producer
import com.fruitexpert.ai.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

@Composable
fun WorkstationScreen(
    activeFruit: FruitData?,
    onFruitLoaded: (FruitData) -> Unit,
    lang: String,
    onLangSwitched: (String) -> Unit,
    apiService: ApiService
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val lifecycleOwner = LocalLifecycleOwner.current

    var isAnalyzing by remember { mutableStateOf(false) }
    var selectedImageBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var showCameraViewfinder by remember { mutableStateOf(false) }

    var selectedTab by remember { mutableStateOf(0) } // 0: Overview, 1: Agronomy, 2: Nutrition

    // Preset Fruits list matching web app
    val presetKeys = listOf("dragonfruit", "mango", "avocado", "durian", "apple")
    val presetNamesEn = listOf("Dragon Fruit", "Mango", "Avocado", "Durian", "Apple")
    val presetNamesBn = listOf("ড্রাগন ফল", "আম", "অ্যাভোকাডো", "ডুরিয়ান", "আপেল")
    val presetNames = if (lang == "bn") presetNamesBn else presetNamesEn

    // CameraX helper elements
    val cameraExecutor: ExecutorService = remember { Executors.newSingleThreadExecutor() }
    var imageCapture: ImageCapture? by remember { mutableStateOf(null) }

    // Launcher for selecting image from gallery
    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch {
                try {
                    isAnalyzing = true
                    val bitmap = decodeUriToBitmap(context, uri)
                    if (bitmap != null) {
                        selectedImageBitmap = bitmap
                        val base64 = encodeBitmapToBase64(bitmap)
                        triggerAnalysis(base64, "image/jpeg", apiService, onFruitLoaded, context, lang)
                    }
                } catch (e: Exception) {
                    Toast.makeText(context, "Failed to load image: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                } finally {
                    isAnalyzing = false
                }
            }
        }
    }

    // Permission launcher for Camera
    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        if (isGranted) {
            showCameraViewfinder = true
        } else {
            Toast.makeText(context, "Camera permission is required to capture live specimens", Toast.LENGTH_LONG).show()
        }
    }

    // Function to trigger analysis through network
    fun triggerPresetAnalysis(key: String) {
        coroutineScope.launch {
            try {
                isAnalyzing = true
                val payload = ApiService.createAnalysisPayload("", "image/jpeg", lang, key)
                val response = apiService.analyzeFruit(payload)
                if (response.success && response.data != null) {
                    onFruitLoaded(response.data)
                    Toast.makeText(context, "Preset loaded successfully", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, response.message ?: "Failed to load preset", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                Toast.makeText(context, "Network Error: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            } finally {
                isAnalyzing = false
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // App header with language toggle
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "FruitExpert AI",
                    color = TextLight,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = (-0.5).sp
                )
                Text(
                    text = if (lang == "bn") "বোটানিক্যাল এআই পোর্টাল" else "Botanical Diagnostics Portal",
                    color = OrangePrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Language Toggle
            Button(
                onClick = { onLangSwitched(if (lang == "bn") "en" else "bn") },
                colors = ButtonDefaults.buttonColors(
                    containerColor = SurfaceDark,
                    contentColor = OrangePrimary
                ),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, BorderDark),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Translate,
                        contentDescription = "Language",
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = if (lang == "bn") "English" else "বাংলা",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Camera Viewfinder overlay
        if (showCameraViewfinder) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.Black)
            ) {
                AndroidView(
                    factory = { ctx ->
                        val previewView = PreviewView(ctx)
                        val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                        cameraProviderFuture.addListener({
                            val cameraProvider = cameraProviderFuture.get()
                            val preview = Preview.Builder().build().also {
                                it.setSurfaceProvider(previewView.surfaceProvider)
                            }
                            imageCapture = ImageCapture.Builder()
                                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                                .build()

                            try {
                                cameraProvider.unbindAll()
                                cameraProvider.bindToLifecycle(
                                    lifecycleOwner,
                                    CameraSelector.DEFAULT_BACK_CAMERA,
                                    preview,
                                    imageCapture
                                )
                            } catch (exc: Exception) {
                                Toast.makeText(ctx, "Failed to launch camera finder", Toast.LENGTH_SHORT).show()
                            }
                        }, ContextCompat.getMainExecutor(ctx))
                        previewView
                    },
                    modifier = Modifier.fillMaxSize()
                )

                // Viewfinder Controls
                Row(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = { showCameraViewfinder = false },
                        colors = ButtonDefaults.buttonColors(containerColor = CardDark),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(text = if (lang == "bn") "বাতিল" else "Cancel", color = TextLight, fontSize = 11.sp)
                    }

                    // Circular Trigger
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(OrangePrimary)
                            .clickable {
                                val capture = imageCapture
                                if (capture != null) {
                                    isAnalyzing = true
                                    showCameraViewfinder = false
                                    capture.takePicture(
                                        cameraExecutor,
                                        object : ImageCapture.OnImageCapturedCallback() {
                                            override fun onCaptureSuccess(imageProxy: ImageProxy) {
                                                val bitmap = imageProxyToBitmap(imageProxy)
                                                imageProxy.close()
                                                if (bitmap != null) {
                                                    selectedImageBitmap = bitmap
                                                    coroutineScope.launch {
                                                        val base64 = encodeBitmapToBase64(bitmap)
                                                        triggerAnalysis(base64, "image/jpeg", apiService, onFruitLoaded, context, lang)
                                                        isAnalyzing = false
                                                    }
                                                } else {
                                                    isAnalyzing = false
                                                }
                                            }

                                            override fun onError(exception: ImageCaptureException) {
                                                isAnalyzing = false
                                                coroutineScope.launch {
                                                    Toast.makeText(context, "Capture failed: ${exception.message}", Toast.LENGTH_LONG).show()
                                                }
                                            }
                                        }
                                    )
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CameraAlt,
                            contentDescription = "Capture",
                            tint = TextLight,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(60.dp))
                }
            }
        } else {
            // Static visual upload welcome panel
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SurfaceDark, RoundedCornerShape(16.dp))
                    .border(1.dp, BorderDark, RoundedCornerShape(16.dp))
                    .padding(20.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (selectedImageBitmap != null) {
                        Image(
                            bitmap = selectedImageBitmap!!.asImageBitmap(),
                            contentDescription = "Selected Sample",
                            modifier = Modifier
                                .height(160.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .border(1.dp, OrangePrimary, RoundedCornerShape(12.dp))
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .background(OrangePrimary.copy(alpha = 0.1f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.FilterFrames,
                                contentDescription = null,
                                tint = OrangePrimary,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                        Text(
                            text = if (lang == "bn") "ডিভাইস ক্যামেরা অথবা আপলোড ব্যবহার করুন" else "Live Camera & Specimen Analyzer",
                            color = TextLight,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (lang == "bn")
                                "তাৎক্ষণিক সনাক্তকরণের জন্য ফলের ছবি তুলুন অথবা গ্যালারি থেকে আপলোড করুন।"
                            else
                                "Capture fresh specimens or load library files to prompt server-side deep classification schemas.",
                            color = TextMuted,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(horizontal = 8.dp),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }

                    // Triggers
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                val hasPermission = ContextCompat.checkSelfPermission(
                                    context,
                                    Manifest.permission.CAMERA
                                ) == PackageManager.PERMISSION_GRANTED
                                if (hasPermission) {
                                    showCameraViewfinder = true
                                } else {
                                    cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                                }
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = OrangePrimary),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(imageVector = Icons.Default.CameraAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = if (lang == "bn") "লাইভ ক্যামেরা" else "Live Camera", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { galleryLauncher.launch("image/*") },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = CardDark),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, BorderDark)
                        ) {
                            Icon(imageVector = Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = if (lang == "bn") "গ্যালারি আপলোড" else "Photo Gallery", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Preset items selection row
        Column(modifier = Modifier.padding(vertical = 16.dp)) {
            Text(
                text = if (lang == "bn") "অথবা নিচের নমুনাগুলো থেকে লোড করুন:" else "Or choose a preset sample fruit to view:",
                color = TextMuted,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(presetKeys.indices.toList()) { idx ->
                    val key = presetKeys[idx]
                    val name = presetNames[idx]
                    Box(
                        modifier = Modifier
                            .background(SurfaceDark, RoundedCornerShape(12.dp))
                            .border(1.dp, BorderDark, RoundedCornerShape(12.dp))
                            .clickable { triggerPresetAnalysis(key) }
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                    ) {
                        Text(
                            text = name,
                            color = OrangePrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Loading Analyzer Indicator
        if (isAnalyzing) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SurfaceDark, RoundedCornerShape(12.dp))
                    .padding(20.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    CircularProgressIndicator(color = OrangePrimary, modifier = Modifier.size(20.dp))
                    Text(
                        text = if (lang == "bn") "নমুনা বিশ্লেষণ করা হচ্ছে, দয়া করে অপেক্ষা করুন..." else "Connecting to server. Running diagnostics...",
                        color = TextLight,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        // Rich Analysis Dashboard Panel
        if (activeFruit != null && !isAnalyzing) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Header of specimen
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(SurfaceDark, RoundedCornerShape(14.dp))
                        .border(1.dp, BorderDark, RoundedCornerShape(14.dp))
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = activeFruit.commonName,
                            color = TextLight,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = activeFruit.scientificName,
                            color = OrangePrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Score Badge
                    Box(
                        modifier = Modifier
                            .background(OrangePrimary.copy(alpha = 0.1f), RoundedCornerShape(10.dp))
                            .border(1.dp, OrangePrimary.copy(alpha = 0.3f), RoundedCornerShape(10.dp))
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "${activeFruit.confidence}% Conf",
                            color = OrangePrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }

                // Scrollable Sub-tabs selector
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val tabs = listOf(
                        if (lang == "bn") "পরিচিতি" else "Overview",
                        if (lang == "bn") "কৃষি চাষাবাদ" else "Agronomy",
                        if (lang == "bn") "পুষ্টি তথ্য" else "Nutrition"
                    )
                    tabs.forEachIndexed { index, title ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (selectedTab == index) OrangePrimary else SurfaceDark)
                                .border(1.dp, if (selectedTab == index) OrangePrimary else BorderDark, RoundedCornerShape(10.dp))
                                .clickable { selectedTab = index }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = title,
                                color = TextLight,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // Active Tab Contents panel
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(SurfaceDark, RoundedCornerShape(16.dp))
                        .border(1.dp, BorderDark, RoundedCornerShape(16.dp))
                        .padding(16.dp)
                ) {
                    when (selectedTab) {
                        0 -> { // Overview Tab
                            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                DashboardSection(
                                    title = if (lang == "bn") "উৎপত্তি ও সংক্ষিপ্ত ইতিহাস" else "Origin & Historical Milestones",
                                    body = activeFruit.originHistory
                                )
                                DashboardSection(
                                    title = if (lang == "bn") "শারীরিক গঠন ও স্বাদ প্রোফাইল" else "Physical & Taste Specifications",
                                    body = activeFruit.physicalCharacteristics
                                )
                                DashboardSection(
                                    title = if (lang == "bn") "প্রধান জাতসমূহ" else "Common Commercial Cultivars",
                                    body = activeFruit.varieties.joinToString("\n\n• ", prefix = "• ")
                                )
                            }
                        }
                        1 -> { // Agronomy Tab
                            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                DashboardSection(
                                    title = if (lang == "bn") "আদর্শ জলবায়ু ও চাষাবাদ পরিস্থিতি" else "Cultivation & Growing Climate",
                                    body = activeFruit.growingConditions
                                )
                                DashboardSection(
                                    title = if (lang == "bn") "ঋতু ও ফসল কাটার সময়" else "Peak Harvesting Season",
                                    body = activeFruit.seasonality
                                )
                                DashboardSection(
                                    title = if (lang == "bn") "শীর্ষ উৎপাদনকারী দেশ ও বাজার" else "Market Top Producers",
                                    body = activeFruit.topProducers.joinToString("\n") { "• ${it.country}: ${it.quantity}" }
                                )
                                DashboardSection(
                                    title = if (lang == "bn") "গ্লোবাল প্রোডাকশন লিডার" else "Global Leader Summary",
                                    body = activeFruit.globalLeader
                                )
                            }
                        }
                        2 -> { // Nutrition Tab
                            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = if (lang == "bn") "ক্যালোরি পরিমাণ (প্রতি ১০০ গ্রাম):" else "Calories (per 100g fresh flesh):",
                                        color = TextMuted,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "${activeFruit.nutritionalValue.caloriesPer100g} kcal",
                                        color = OrangePrimary,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                                DashboardSection(
                                    title = if (lang == "bn") "প্রধান ভিটামিনসমূহ" else "Vitamins",
                                    body = activeFruit.nutritionalValue.vitamins.joinToString(", ")
                                )
                                DashboardSection(
                                    title = if (lang == "bn") "প্রধান খনিজ উপাদান" else "Minerals",
                                    body = activeFruit.nutritionalValue.minerals.joinToString(", ")
                                )
                                DashboardSection(
                                    title = if (lang == "bn") "মেডিকেল ও স্বাস্থ্য উপকারিতা" else "Primary Medical/Wellness Benefits",
                                    body = activeFruit.nutritionalValue.healthBenefits.joinToString("\n\n• ", prefix = "• ")
                                )

                                // Warnings
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(RedBackground.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                                        .border(1.dp, RedWarning.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                                        .padding(12.dp)
                                ) {
                                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = RedWarning, modifier = Modifier.size(16.dp))
                                            Text(text = if (lang == "bn") "অ্যালার্জি এবং সতর্কতা" else "Allergies & Contraindications", color = RedWarning, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                        Text(text = activeFruit.healthWarnings, color = TextLight.copy(alpha = 0.9f), fontSize = 11.sp, lineHeight = 16.sp)
                                    }
                                }
                            }
                        }
                    }
                }

                // Copy JSON Data / Share Data Actions
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = {
                            val dataString = """
                                Name: ${activeFruit.commonName} (${activeFruit.scientificName})
                                Confidence: ${activeFruit.confidence}%
                                Family details: ${activeFruit.growingConditions}
                            """.trimIndent()
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                            val clip = android.content.ClipData.newPlainText("Fruit Data JSON", dataString)
                            clipboard.setPrimaryClip(clip)
                            Toast.makeText(context, if (lang == "bn") "মেটাডেটা ক্লিপবোর্ডে কপি করা হয়েছে" else "JSON analytical logs copied to clipboard", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CardDark),
                        border = BorderStroke(1.dp, BorderDark),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = if (lang == "bn") "ডাটা কপি করুন" else "Copy JSON", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = {
                            val shareIntent = android.content.Intent().apply {
                                action = android.content.Intent.ACTION_SEND
                                putExtra(android.content.Intent.EXTRA_TEXT, "Identified fruit: ${activeFruit.commonName} (${activeFruit.scientificName}) via FruitExpert AI!")
                                type = "text/plain"
                            }
                            context.startActivity(android.content.Intent.createChooser(shareIntent, "Share Fruit Specs"))
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CardDark),
                        border = BorderStroke(1.dp, BorderDark),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(imageVector = Icons.Default.Share, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = if (lang == "bn") "শেয়ার করুন" else "Share Summary", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun DashboardSection(title: String, body: String) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(
            text = title,
            color = OrangePrimary,
            fontSize = 11.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 0.5.sp
        )
        Text(
            text = body,
            color = TextLight.copy(alpha = 0.9f),
            fontSize = 12.sp,
            lineHeight = 18.sp
        )
    }
}

// Helpers for decoding URIs and encoding images in Background threads
suspend fun decodeUriToBitmap(context: Context, uri: Uri): Bitmap? = withContext(Dispatchers.IO) {
    var inputStream: InputStream? = null
    try {
        inputStream = context.contentResolver.openInputStream(uri)
        BitmapFactory.decodeStream(inputStream)
    } catch (e: Exception) {
        null
    } finally {
        inputStream?.close()
    }
}

suspend fun encodeBitmapToBase64(bitmap: Bitmap): String = withContext(Dispatchers.IO) {
    val outputStream = ByteArrayOutputStream()
    bitmap.compress(Bitmap.CompressFormat.JPEG, 80, outputStream)
    val bytes = outputStream.toByteArray()
    Base64.encodeToString(bytes, Base64.NO_WRAP)
}

fun imageProxyToBitmap(image: ImageProxy): Bitmap? {
    val plane = image.planes[0]
    val buffer = plane.buffer
    val bytes = ByteArray(buffer.capacity())
    buffer.get(bytes)
    return BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
}

fun triggerAnalysis(
    base64: String,
    mimeType: String,
    apiService: ApiService,
    onFruitLoaded: (FruitData) -> Unit,
    context: Context,
    language: String
) {
    val coroutineScope = kotlinx.coroutines.CoroutineScope(Dispatchers.Main)
    coroutineScope.launch {
        try {
            val payload = ApiService.createAnalysisPayload(base64, mimeType, language)
            val response = apiService.analyzeFruit(payload)
            if (response.success && response.data != null) {
                onFruitLoaded(response.data)
                Toast.makeText(context, "Analysis complete", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(context, response.message ?: "Analysis failed", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            Toast.makeText(context, "Network issue: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
        }
    }
}
