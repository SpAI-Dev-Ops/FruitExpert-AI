package com.fruitexpert.ai.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fruitexpert.ai.R
import com.fruitexpert.ai.ui.theme.*

@Composable
fun SettingsScreen(lang: String) {
    val context = LocalContext.current
    var showPrivacyContent by remember { mutableStateOf(false) }

    val feedbackFormUrl = "https://docs.google.com/forms/d/e/1FAIpQLScyO78X4DbeK5Sdfw0G5B5DqU9eK-vS_D601_F7b7-601_F7b/viewform"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Section Header
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .background(OrangePrimary.copy(alpha = 0.1f), RoundedCornerShape(8.dp))
                    .padding(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = null,
                    tint = OrangePrimary,
                    modifier = Modifier.size(20.dp)
                )
            }
            Text(
                text = stringResource(id = R.string.info_title),
                color = TextLight,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
        }

        // Info Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(SurfaceDark, RoundedCornerShape(12.dp))
                .border(1.dp, BorderDark, RoundedCornerShape(12.dp))
                .padding(16.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "FruitExpert AI Platform",
                    color = OrangePrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = stringResource(id = R.string.info_desc),
                    color = TextLight.copy(alpha = 0.9f),
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )
            }
        }

        // Interaction Links
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Feedback Form
            Button(
                onClick = {
                    try {
                        val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(feedbackFormUrl))
                        context.startActivity(browserIntent)
                    } catch (e: Exception) {
                        Toast.makeText(context, "Could not open browser: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = OrangePrimary),
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(vertical = 12.dp)
            ) {
                Icon(imageVector = Icons.Default.ThumbUp, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = stringResource(id = R.string.btn_feedback), fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }

            // Contact Us
            Button(
                onClick = {
                    val emailIntent = Intent(Intent.ACTION_SENDTO).apply {
                        data = Uri.parse("mailto:support@fruitexpert.co.uk")
                        putExtra(Intent.EXTRA_SUBJECT, "FruitExpert AI Support (Android)")
                    }
                    try {
                        context.startActivity(Intent.createChooser(emailIntent, "Send Email"))
                    } catch (e: Exception) {
                        Toast.makeText(context, "No email client installed", Toast.LENGTH_SHORT).show()
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = CardDark),
                border = BorderStroke(1.dp, BorderDark),
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(vertical = 12.dp)
            ) {
                Icon(imageVector = Icons.Default.Email, contentDescription = null, modifier = Modifier.size(16.dp), tint = OrangePrimary)
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = stringResource(id = R.string.btn_contact), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextLight)
            }

            // Privacy Policy Toggle
            Button(
                onClick = { showPrivacyContent = !showPrivacyContent },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = CardDark),
                border = BorderStroke(1.dp, BorderDark),
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(vertical = 12.dp)
            ) {
                Icon(imageVector = Icons.Default.PrivacyTip, contentDescription = null, modifier = Modifier.size(16.dp), tint = OrangePrimary)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = stringResource(id = R.string.btn_privacy),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextLight
                )
            }
        }

        // Animated Privacy Policy Panel
        AnimatedVisibility(visible = showPrivacyContent) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SurfaceDark, RoundedCornerShape(12.dp))
                    .border(1.dp, BorderDark, RoundedCornerShape(12.dp))
                    .padding(14.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = if (lang == "bn") "গোপনীয়তা নীতি ও শর্তাবলী" else "Privacy Guidelines",
                        color = OrangePrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (lang == "bn") """
                            ১. আমরা আপনার গোপনীয়তাকে সম্মান করি। FruitExpert AI আপনার ছবি বা স্ক্যানকৃত ফাইল কোনো ক্লাউড সার্ভারে স্থায়ীভাবে সংরক্ষণ করে না।
                            ২. ক্যামেরা এবং লাইভ ভিউফাইন্ডার ব্যবহারের সমস্ত অনুমতি সম্পূর্ণ অন-ডিভাইস প্রসেস করা হয়।
                            ৩. স্ক্যানকৃত তথ্যের ইতিহাস এবং পছন্দসমূহ সম্পূর্ণ নিরাপদে আপনার ব্রাউজার বা ডিভাইসের লোকাল স্টোরেজে সংরক্ষণ করা হয়।
                        """.trimIndent()
                        else """
                            1. We respect your privacy. FruitExpert AI does not persist uploaded scans or snapshots to any permanent remote databases.
                            2. Camera hardware operations are executed strictly on-device to produce visual diagnostics payloads.
                            3. Historical search elements are saved on your sandbox local storage and can be wiped instantly.
                        """.trimIndent(),
                        color = TextLight.copy(alpha = 0.85f),
                        fontSize = 11.sp,
                        lineHeight = 16.sp
                    )
                }
            }
        }

        // App details at bottom
        Column(
            modifier = Modifier.fillMaxWidth().padding(top = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = "FruitExpert AI Android Client",
                color = TextLight,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Version: 1.0.0 (Build 1)",
                color = TextMuted,
                fontSize = 10.sp
            )
            Text(
                text = stringResource(id = R.string.copyright),
                color = TextMuted,
                fontSize = 10.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}
