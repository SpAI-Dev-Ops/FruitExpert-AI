package com.fruitexpert.ai.data

import kotlinx.serialization.Serializable

@Serializable
data class FruitAnalysisResponse(
    val success: Boolean,
    val data: FruitData? = null,
    val error: String? = null,
    val message: String? = null
)

@Serializable
data class FruitData(
    val commonName: String,
    val scientificName: String,
    val confidence: Int,
    val originHistory: String,
    val physicalCharacteristics: String,
    val nutritionalValue: NutritionalValue,
    val varieties: List<String>,
    val culinaryUsesStorage: String,
    val topProducers: List<Producer>,
    val globalLeader: String,
    val majorExporters: List<String>,
    val growingConditions: String,
    val seasonality: String,
    val interestingFacts: List<String>,
    val healthWarnings: String
)

@Serializable
data class NutritionalValue(
    val vitamins: List<String>,
    val minerals: List<String>,
    val healthBenefits: List<String>,
    val caloriesPer100g: Int
)

@Serializable
data class Producer(
    val country: String,
    val quantity: String,
    val valueNumeric: Int
)

@Serializable
data class ChatRequest(
    val messages: List<ChatMessage>,
    val activeFruit: FruitData? = null,
    val language: String
)

@Serializable
data class ChatMessage(
    val role: String, // "user" or "model"
    val content: String
)

@Serializable
data class ChatResponse(
    val success: Boolean,
    val content: String? = null,
    val message: String? = null
)

@Serializable
data class QuickActionRequest(
    val fruitName: String,
    val actionType: String,
    val scientificName: String? = null
)

@Serializable
data class QuickActionResponse(
    val success: Boolean,
    val content: String? = null,
    val message: String? = null
)
