package com.fruitexpert.ai.ui.theme

import androidx.compose.ui.graphics.Color

// Dark luxurious palette matching original web layout
val BackgroundDark = Color(0xFF020617) // Slate 950
val SurfaceDark = Color(0xFF0F172A)    // Slate 900
val CardDark = Color(0xFF1E293B)       // Slate 800
val BorderDark = Color(0xFF334155)     // Slate 700

val OrangePrimary = Color(0xFFF97316)  // Orange 500
val OrangeHover = Color(0xFFEA580C)    // Orange 600
val TextLight = Color(0xFFF8FAFC)      // Slate 50
val TextMuted = Color(0xFF94A3B8)      // Slate 400

val RedWarning = Color(0xFFEF4444)     // Red 500
val RedBackground = Color(0xFF450A0A)  // Red 950
val GreenSuccess = Color(0xFF22C55E)   // Green 500
val GreenBackground = Color(0xFF052E16)// Green 950
