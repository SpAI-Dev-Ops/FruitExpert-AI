package com.fruitexpert.ai.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronDown
import androidx.compose.material.icons.filled.ChevronUp
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fruitexpert.ai.ui.theme.*

data class FaqItem(val question: String, val answer: String)

@Composable
fun FaqScreen(lang: String) {
    val faqListEn = listOf(
        FaqItem(
            "What is FruitExpert AI?",
            "FruitExpert AI is an AI-powered tool that helps users identify fruits and explore botanical, nutritional, and agricultural information from fruit images and questions."
        ),
        FaqItem(
            "How do I identify a fruit?",
            "Open Live Camera or upload a fruit image, then start the analysis. FruitExpert AI will provide an AI-generated identification and related information."
        ),
        FaqItem(
            "Does Live Camera require permission?",
            "Yes. Your browser or mobile operating system must allow camera access, and the app must communicate through a secure connection."
        ),
        FaqItem(
            "Can I use FruitExpert AI in Bengali?",
            "Yes. FruitExpert AI supports English and বাংলা. You can switch languages instantly using the selector at the top-right of the Workstation tab."
        ),
        FaqItem(
            "Is the AI information always accurate?",
            "AI-generated information can contain errors. Users should verify important agricultural, nutritional, medical, pesticide, or treatment information with qualified professionals and reliable local sources."
        ),
        FaqItem(
            "Does FruitExpert AI store my photos?",
            "The current application uses local sandboxed storage on your device for history and favorites. We do not store your images or uploads on any remote servers."
        ),
        FaqItem(
            "How can I send feedback?",
            "Use the 'Give Feedback' button in the Info tab to open the FruitExpert AI Google Feedback form in a secure web browser tab."
        ),
        FaqItem(
            "Can I download my analysis?",
            "Yes. On supported devices, you can copy the full raw analysis output as structured JSON or share the summary text directly."
        )
    )

    val faqListBn = listOf(
        FaqItem(
            "FruitExpert AI কী?",
            "FruitExpert AI হলো একটি এআই-চালিত উন্নত টুল যা ব্যবহারকারীদের ফলের ছবি এবং চ্যাট প্রশ্নের মাধ্যমে বিভিন্ন ফল সনাক্ত করতে এবং এ সংক্রান্ত উদ্ভিদবিজ্ঞান, পুষ্টি এবং কৃষি তথ্য অনুসন্ধান করতে সাহায্য করে।"
        ),
        FaqItem(
            "আমি কীভাবে একটি ফল সনাক্ত করব?",
            "লাইভ ক্যামেরা খুলুন অথবা ফলের একটি ছবি আপলোড করুন এবং বিশ্লেষণ শুরু করুন। FruitExpert AI আপনাকে একটি কৃত্রিম বুদ্ধিমত্তা-ভিত্তিক সনাক্তকরণ ফলাফল এবং সংশ্লিষ্ট কৃষি মেট্রিক্স প্রদান করবে।"
        ),
        FaqItem(
            "লাইভ ক্যামেরার কি অনুমতি প্রয়োজন হয়?",
            "হ্যাঁ। আপনার মোবাইল অপারেটিং সিস্টেমে ক্যামেরার অনুমতি প্রদান করতে হবে এবং অ্যাপ্লিকেশনটি অবশ্যই একটি নিরাপদ HTTPS সংযোগের মাধ্যমে কাজ করবে।"
        ),
        FaqItem(
            "আমি কি FruitExpert AI বাংলা ভাষায় ব্যবহার করতে পারি?",
            "হ্যাঁ। FruitExpert AI ইংরেজি এবং বাংলা উভয় ভাষা সমর্থন করে। আপনি ড্যাশবোর্ড স্ক্রিনের উপরের-ডানদিকের ভাষা নির্বাচক বোতাম থেকে যেকোনো সময় ভাষা পরিবর্তন করতে পারেন।"
        ),
        FaqItem(
            "এআই দ্বারা প্রাপ্ত তথ্য কি সর্বদা সঠিক হয়?",
            "এআই-উত্পন্ন তথ্যে ভুলত্রুটি থাকতে পারে। গুরুত্বপূর্ণ কৃষি, পুষ্টি সংক্রান্ত, চিকিৎসা, কীটনাশক বা বিশেষ ফলন চিকিৎসার সিদ্ধান্ত নেওয়ার আগে সর্বদা সংশ্লিষ্ট বিশেষজ্ঞ এবং নির্ভরযোগ্য স্থানীয় উেসর সাথে যাচাই করে নিন।"
        ),
        FaqItem(
            "FruitExpert AI কি আমার ছবি সংরক্ষণ করে?",
            "বর্তমান অ্যাপ্লিকেশনটি হিস্ট্রি সচল রাখতে শুধুমাত্র আপনার ডিভাইসের লোকাল স্টোরেজ ব্যবহার করে। আমরা কোনো ক্লাউড বা সার্ভার-সাইড ডাটাবেজে আপনার ছবি সংরক্ষণ করি না।"
        ),
        FaqItem(
            "আমি কীভাবে ফিডব্যাক পাঠাতে পারি?",
            "তথ্য (Info) ট্যাবের 'ফিডব্যাক' বোতামটি ব্যবহার করে নতুন ব্রাউজার ট্যাবে FruitExpert AI-এর জন্য অফিশিয়াল গুগল ফিডব্যাক ফর্মটি খুলুন এবং মতামত জানান।"
        ),
        FaqItem(
            "আমি কি আমার ফল সনাক্তকরণের ডেটা ডাউনলোড করতে পারব?",
            "হ্যাঁ। ড্যাশবোর্ড থেকে আপনি সরাসরি সম্পূর্ণ ডাটা শিট JSON ফাইল হিসেবে কপি বা এক্সপোর্ট করতে পারবেন অথবা বিবরণী শেয়ার করতে পারবেন।"
        )
    )

    val currentList = if (lang == "bn") faqListBn else faqListEn

    var expandedIndex by remember { mutableStateOf<Int?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .padding(16.dp)
    ) {
        // FAQ Title
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .background(OrangePrimary.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                    .border(1.dp, OrangePrimary.copy(alpha = 0.2f), RoundedCornerShape(12.dp))
                    .padding(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.HelpOutline,
                    contentDescription = null,
                    tint = OrangePrimary,
                    modifier = Modifier.size(24.dp)
                )
            }
            Column {
                Text(
                    text = if (lang == "bn") "জিজ্ঞাসিত প্রশ্নাবলী (FAQ)" : "Frequently Asked Questions",
                    color = TextLight,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = if (lang == "bn") "FruitExpert AI সম্পর্কে সাধারণ জিজ্ঞাসা" else "Common inquiries about FruitExpert AI",
                    color = TextMuted,
                    fontSize = 11.sp
                )
            }
        }

        // Accordion List
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            itemsIndexed(currentList) { idx, item ->
                val isExpanded = expandedIndex == idx
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(SurfaceDark)
                        .border(1.dp, if (isExpanded) OrangePrimary.copy(alpha = 0.3f) else BorderDark, RoundedCornerShape(12.dp))
                        .clickable { expandedIndex = if (isExpanded) null else idx }
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Q${idx + 1}. ",
                                color = OrangePrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = item.question,
                                color = TextLight,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Icon(
                            imageVector = if (isExpanded) Icons.Default.ChevronUp else Icons.Default.ChevronDown,
                            contentDescription = null,
                            tint = if (isExpanded) OrangePrimary else TextMuted,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    AnimatedVisibility(visible = isExpanded) {
                        Column(modifier = Modifier.padding(top = 10.dp, start = 18.dp)) {
                            Box(modifier = Modifier.height(1.dp).fillMaxWidth().background(BorderDark.copy(alpha = 0.5f)).padding(bottom = 8.dp))
                            Row {
                                Text(
                                    text = "A: ",
                                    color = TextMuted,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = item.answer,
                                    color = TextLight.copy(alpha = 0.9f),
                                    fontSize = 12.sp,
                                    lineHeight = 18.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Safety disclaimer at bottom
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 12.dp)
                .background(OrangePrimary.copy(alpha = 0.05f), RoundedCornerShape(12.dp))
                .border(1.dp, OrangePrimary.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                .padding(12.dp)
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(
                    imageVector = Icons.Default.Shield,
                    contentDescription = null,
                    tint = OrangePrimary,
                    modifier = Modifier.size(18.dp)
                )
                Column {
                    Text(
                        text = if (lang == "bn") "আইনি সতর্কতা" else "EDUCATIONAL DISCLAIMER",
                        color = OrangePrimary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (lang == "bn")
                            "অ্যাপে প্রাপ্ত উদ্ভিদ তথ্য সম্পূর্ণ শিক্ষামূলক উদ্দেশ্যে তৈরি। এটি কোনো পেশাদার কৃষি সেবা বা কীটনাশক প্রেসক্রিপশনের বিকল্প নয়।"
                        else
                            "All botanical data is for educational reference only. It should not replace certified agricultural consultation.",
                        color = TextMuted,
                        fontSize = 10.sp,
                        lineHeight = 14.sp
                    )
                }
            }
        }
    }
}
