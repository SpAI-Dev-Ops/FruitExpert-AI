package com.fruitexpert.ai.data

import com.jakewharton.retrofit2.converter.kotlinx.serialization.asConverterFactory
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.http.Body
import retrofit2.http.POST
import java.util.concurrent.TimeUnit

interface ApiService {

    @POST("api/analyze-fruit")
    suspend fun analyzeFruit(
        @Body body: RequestBody
    ): FruitAnalysisResponse

    @POST("api/chat")
    suspend fun chat(
        @Body request: ChatRequest
    ): ChatResponse

    @POST("api/quick-action")
    suspend fun quickAction(
        @Body request: QuickActionRequest
    ): QuickActionResponse

    companion object {
        // Points to our live secure Cloud Run server
        private const val BASE_URL = "https://ais-pre-xs764p6itu7z4dq7i4tcdp-441678645208.asia-southeast1.run.app/"
        
        // Alternative URL for Android Emulator localhost connections: "http://10.0.2.2:3000/"

        private val json = Json {
            ignoreUnknownKeys = true
            coerceInputValues = true
            encodeDefaults = true
        }

        fun create(): ApiService {
            val loggingInterceptor = HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.BODY
            }

            val okHttpClient = OkHttpClient.Builder()
                .connectTimeout(45, TimeUnit.SECONDS)
                .readTimeout(45, TimeUnit.SECONDS)
                .writeTimeout(45, TimeUnit.SECONDS)
                .addInterceptor(loggingInterceptor)
                .build()

            val contentType = "application/json".toMediaType()

            return Retrofit.Builder()
                .baseUrl(BASE_URL)
                .client(okHttpClient)
                .addConverterFactory(json.asConverterFactory(contentType))
                .build()
                .create(ApiService::class.java)
        }

        // Helper to construct base64 request payload for image classification
        fun createAnalysisPayload(imageBase64: String, mimeType: String, language: String, presetKey: String? = null): RequestBody {
            val jsonString = """
                {
                    "imageBase64": "data:$mimeType;base64,$imageBase64",
                    "mimeType": "$mimeType",
                    "language": "$language"
                    ${if (presetKey != null) ",\"presetKey\": \"$presetKey\"" else ""}
                }
            """.trimIndent()
            return jsonString.toRequestBody("application/json".toMediaType())
        }
    }
}
