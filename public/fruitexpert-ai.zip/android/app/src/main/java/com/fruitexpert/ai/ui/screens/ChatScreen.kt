package com.fruitexpert.ai.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fruitexpert.ai.data.ApiService
import com.fruitexpert.ai.data.ChatMessage
import com.fruitexpert.ai.data.ChatRequest
import com.fruitexpert.ai.data.FruitData
import com.fruitexpert.ai.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun ChatScreen(
    activeFruit: FruitData?,
    lang: String,
    apiService: ApiService
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val scrollState = rememberLazyListState()

    var messages by remember {
        mutableStateOf(
            listOf(
                ChatMessage(
                    role = "model",
                    content = if (lang == "bn")
                        "স্বাগতম! আমি FruitExpert AI। পুষ্টিগুণ, চাষাবাদ, রোগ দমন বা যেকোনো ফলের উৎপত্তি সম্পর্কে জিজ্ঞাসা করতে নিচে আপনার প্রশ্নটি লিখুন!"
                    else
                        "Welcome! I am your FruitExpert AI. Feel free to ask about any fruit's nutritional value, cultivation tips, recipes, or pest management. How can I help you today?"
                )
            )
        )
    }

    var textInput by remember { mutableStateOf("") }
    var isSending by remember { mutableStateOf(false) }

    val suggestedQuestionsEn = listOf(
        "Is kiwi skin edible?",
        "Which fruits have the most Vitamin C?",
        "What is the origin of Apples?",
        "How do mangoes grow?"
    )

    val suggestedQuestionsBn = listOf(
        "কিউই ফলের খোসা কি খাওয়া যায়?",
        "কোন ফলে সবচেয়ে বেশি ভিটামিন সি থাকে?",
        "আপেলের উৎপত্তি কোথায়?",
        "আম কীভাবে চাষ করতে হয়?"
    )

    val suggestions = if (lang == "bn") suggestedQuestionsBn else suggestedQuestionsEn

    fun sendMessage(content: String) {
        if (content.isBlank() || isSending) return
        
        // Add user message to list
        val updatedMessages = messages + ChatMessage(role = "user", content = content)
        messages = updatedMessages
        textInput = ""
        isSending = true

        coroutineScope.launch {
            try {
                // Scroll to bottom
                scrollState.animateScrollToItem(updatedMessages.size - 1)

                // Request Chat
                val response = apiService.chat(
                    ChatRequest(
                        messages = updatedMessages,
                        activeFruit = activeFruit,
                        language = lang
                    )
                )

                if (response.success && response.content != null) {
                    messages = messages + ChatMessage(role = "model", content = response.content)
                } else {
                    messages = messages + ChatMessage(
                        role = "model",
                        content = if (lang == "bn")
                            "দুঃখিত, আমি উত্তর দিতে পারছি না। দয়া করে নেটওয়ার্ক চেক করে আবার চেষ্টা করুন।"
                        else
                            "My apologies. I encountered a server timeout. Please check your internet connection and try again."
                    )
                }
            } catch (e: Exception) {
                messages = messages + ChatMessage(
                    role = "model",
                    content = "Error: ${e.localizedMessage ?: "Could not reach server"}"
                )
            } finally {
                isSending = false
                // Scroll to bottom again
                coroutineScope.launch {
                    if (messages.isNotEmpty()) {
                        scrollState.animateScrollToItem(messages.size - 1)
                    }
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .padding(12.dp)
    ) {
        // Chat Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .background(OrangePrimary.copy(alpha = 0.1f), RoundedCornerShape(8.dp))
                        .padding(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Chat,
                        contentDescription = null,
                        tint = OrangePrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Column {
                    Text(
                        text = if (lang == "bn") "এআই পরামর্শক" else "AI Advisor",
                        color = TextLight,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    if (activeFruit != null) {
                        Text(
                            text = if (lang == "bn") "আলোচনার বিষয়: ${activeFruit.commonName}" else "Context: ${activeFruit.commonName}",
                            color = OrangePrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            // Clear Chat Action
            IconButton(
                onClick = {
                    messages = listOf(
                        ChatMessage(
                            role = "model",
                            content = if (lang == "bn")
                                "স্বাগতম! আমি FruitExpert AI। আপনার প্রশ্নটি নিচে টাইপ করুন!"
                            else
                                "Welcome! Ask me anything about fruits and agriculture."
                        )
                    )
                    Toast.makeText(context, if (lang == "bn") "চ্যাট ইতিহাস মুছে ফেলা হয়েছে" else "Chat history cleared", Toast.LENGTH_SHORT).show()
                }
            ) {
                Icon(
                    imageVector = Icons.Default.DeleteSweep,
                    contentDescription = "Clear History",
                    tint = TextMuted
                )
            }
        }

        // Chat Messages List
        LazyColumn(
            state = scrollState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(messages) { msg ->
                val isUser = msg.role == "user"
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.85f)
                            .wrapContentWidth(align = if (isUser) Alignment.End else Alignment.Start)
                            .clip(
                                RoundedCornerShape(
                                    topStart = 16.dp,
                                    topEnd = 16.dp,
                                    bottomStart = if (isUser) 16.dp else 4.dp,
                                    bottomEnd = if (isUser) 4.dp else 16.dp
                                )
                            )
                            .background(if (isUser) OrangePrimary else SurfaceDark)
                            .border(
                                1.dp,
                                if (isUser) OrangePrimary else BorderDark,
                                RoundedCornerShape(
                                    topStart = 16.dp,
                                    topEnd = 16.dp,
                                    bottomStart = if (isUser) 16.dp else 4.dp,
                                    bottomEnd = if (isUser) 4.dp else 16.dp
                                )
                            )
                            .padding(12.dp)
                    ) {
                        Column {
                            Text(
                                text = if (isUser) (if (lang == "bn") "আপনি" else "You") else "FruitExpert AI",
                                color = if (isUser) TextLight else OrangePrimary,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(bottom = 4.dp)
                            )
                            Text(
                                text = msg.content,
                                color = TextLight,
                                fontSize = 13.sp,
                                lineHeight = 18.sp
                            )
                        }
                    }
                }
            }

            if (isSending) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Start
                    ) {
                        Box(
                            modifier = Modifier
                                .background(SurfaceDark, RoundedCornerShape(12.dp))
                                .padding(12.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    strokeWidth = 2.dp,
                                    color = OrangePrimary
                                )
                                Text(
                                    text = if (lang == "bn") "পরামর্শক লিখছেন..." else "Advisor is typing...",
                                    color = TextMuted,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Suggested prompts list
        if (messages.size == 1 && !isSending) {
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(suggestions) { query ->
                    Box(
                        modifier = Modifier
                            .background(SurfaceDark, RoundedCornerShape(20.dp))
                            .border(1.dp, BorderDark, RoundedCornerShape(20.dp))
                            .clickable { sendMessage(query) }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = query,
                            color = OrangePrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Input Box
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TextField(
                value = textInput,
                onValueChange = { textInput = it },
                placeholder = {
                    Text(
                        text = if (lang == "bn") "ফলের পুষ্টি ও চাষাবাদ নিয়ে লিখুন..." else "Ask about nutrition, gardening, cultivars...",
                        color = TextMuted,
                        fontSize = 13.sp
                    )
                },
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .border(1.dp, BorderDark, RoundedCornerShape(12.dp)),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = SurfaceDark,
                    unfocusedContainerColor = SurfaceDark,
                    disabledContainerColor = SurfaceDark,
                    focusedTextColor = TextLight,
                    unfocusedTextColor = TextLight,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent
                ),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { sendMessage(textInput) }),
                maxLines = 3
            )

            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(if (textInput.isNotBlank() && !isSending) OrangePrimary else CardDark)
                    .clickable(enabled = textInput.isNotBlank() && !isSending) { sendMessage(textInput) },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Send,
                    contentDescription = "Send",
                    tint = TextLight,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}
