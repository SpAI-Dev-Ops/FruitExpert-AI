package com.fruitexpert.ai

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import com.fruitexpert.ai.data.ApiService
import com.fruitexpert.ai.ui.screens.MainScreen
import com.fruitexpert.ai.ui.theme.FruitExpertAITheme

class MainActivity : ComponentActivity() {

    private val apiService by lazy { ApiService.create() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Persistent locale cache using SharedPreferences
        val sharedPref = getSharedPreferences("fruit_expert_prefs", Context.MODE_PRIVATE)
        val savedLang = sharedPref.getString("preferred_language", "en") ?: "en"

        setContent {
            var language by remember { mutableStateOf(savedLang) }

            FruitExpertAITheme {
                MainScreen(
                    apiService = apiService,
                    lang = language,
                    onLangSwitched = { newLang ->
                        language = newLang
                        sharedPref.edit().putString("preferred_language", newLang).apply()
                    }
                )
            }
        }
    }
}
