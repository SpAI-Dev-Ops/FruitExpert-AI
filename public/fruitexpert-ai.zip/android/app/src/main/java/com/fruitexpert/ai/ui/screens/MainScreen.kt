package com.fruitexpert.ai.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fruitexpert.ai.R
import com.fruitexpert.ai.data.ApiService
import com.fruitexpert.ai.data.FruitData
import com.fruitexpert.ai.ui.theme.BackgroundDark
import com.fruitexpert.ai.ui.theme.BorderDark
import com.fruitexpert.ai.ui.theme.OrangePrimary
import com.fruitexpert.ai.ui.theme.SurfaceDark

sealed class Screen(val route: String, val icon: ImageVector, val labelResId: Int) {
    object Workstation : Screen("workstation", Icons.Default.Dashboard, R.string.nav_workstation)
    object Chat : Screen("chat", Icons.Default.Chat, R.string.nav_chat)
    object FAQ : Screen("faq", Icons.Default.Help, R.string.nav_faq)
    object Info : Screen("info", Icons.Default.Info, R.string.nav_info)
}

@Composable
fun MainScreen(
    apiService: ApiService,
    lang: String,
    onLangSwitched: (String) -> Unit
) {
    var currentScreen by remember { mutableStateOf<Screen>(Screen.Workstation) }
    var activeFruit by remember { mutableStateOf<FruitData?>(null) }

    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = SurfaceDark,
                tonalElevation = 8.dp,
                modifier = Modifier.height(64.dp)
            ) {
                val items = listOf(
                    Screen.Workstation,
                    Screen.Chat,
                    Screen.FAQ,
                    Screen.Info
                )
                items.forEach { screen ->
                    NavigationBarItem(
                        selected = currentScreen.route == screen.route,
                        onClick = { currentScreen = screen },
                        icon = {
                            Icon(
                                imageVector = screen.icon,
                                contentDescription = stringResource(id = screen.labelResId),
                                modifier = Modifier.size(20.dp)
                            )
                        },
                        label = {
                            Text(
                                text = stringResource(id = screen.labelResId),
                                fontSize = 10.sp,
                                maxLines = 1
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = OrangePrimary,
                            selectedTextColor = OrangePrimary,
                            unselectedIconColor = MaterialTheme.colorScheme.secondary,
                            unselectedTextColor = MaterialTheme.colorScheme.secondary,
                            indicatorColor = SurfaceDark
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(BackgroundDark)
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                is Screen.Workstation -> {
                    WorkstationScreen(
                        activeFruit = activeFruit,
                        onFruitLoaded = { activeFruit = it },
                        lang = lang,
                        onLangSwitched = onLangSwitched,
                        apiService = apiService
                    )
                }
                is Screen.Chat -> {
                    ChatScreen(
                        activeFruit = activeFruit,
                        lang = lang,
                        apiService = apiService
                    )
                }
                is Screen.FAQ -> {
                    FaqScreen(
                        lang = lang
                    )
                }
                is Screen.Info -> {
                    SettingsScreen(
                        lang = lang
                    )
                }
            }
        }
    }
}
